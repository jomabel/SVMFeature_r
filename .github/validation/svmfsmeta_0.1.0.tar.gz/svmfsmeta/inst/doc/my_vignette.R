## ----setup, include = FALSE, eval = TRUE--------------------------------------
has_colon_data <- requireNamespace("plsgenomics", quietly = TRUE)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = has_colon_data,
  error = FALSE,
  message = FALSE
)

## ----colon-data---------------------------------------------------------------
library(svmfsmeta)

# 1. Load Colon and recode its response: 1 (normal) -> 1, 2 (tumor) -> -1
data("Colon", package = "plsgenomics")
data <- data.frame(y = ifelse(Colon$Y == 2, -1, 1), Colon$X)
names(data) <- c("y", paste0("x", seq_len(ncol(Colon$X))))

# 2. Normalize input features (Min-Max scaling to [0, 1])
input_cols <- names(data)[-1]
scaler <- function(x) {
  rng <- range(x, na.rm = TRUE)
  if (rng[1] == rng[2]) return(rep(0.5, length(x)))
  (x - rng[1]) / (rng[2] - rng[1])
}
data[, input_cols] <- as.data.frame(lapply(data[, input_cols], scaler))

## ----colon-optimize, results='hide'-------------------------------------------
# Define input and output column names
input_cols <- names(data)[-1]
output_col <- names(data)[1]

# Initialize svm_fs_meta object
# You can choose between different optimization objectives:
# - "DIST-EPS": Maximizes margin and minimizes error (default).
# - "MC": Minimizes false negatives and false positives separately.

set.seed(42)
obj <- svm_fs_meta(
  data = data,
  inputs = input_cols,
  output = output_col,
  pop_size = 10,
  num_fea = 5,
  n_iter = 10,
  mode = "iters",
  objective = "DIST-EPS",
  # Advanced parameters (optional, shown here with defaults)
  clones = 0,
  p_mutation = 0.7,
  p_mut_ind = 0.4,
  p_mut_fea = 0.4,
  p_mut_coord = 0.2,
  mut_coord = 0
)

# Execute optimization
result <- run.svm_fs_meta(obj)

## ----colon-inspect------------------------------------------------------------
solutions_table <- result$population$df_solutions
pareto_front <- solutions_table[solutions_table$FRONT == 1, , drop = FALSE]

front_solutions <- Filter(
  function(s) s$front == 1,
  result$population$solution_list
)
selected <- front_solutions[[1]]
selected$features      # Selected predictor names
selected$plane_coord   # Normal coefficients, in the same predictor order
selected$plane_term_b  # Intercepts: negative-class margin, positive-class margin, central plane
selected[c("accuracy", "precision", "recall", "f1", "kappa", "auc", "conf_matrix")]

## ----colon-plot, fig.width=6, fig.height=4------------------------------------
# Plot the first front of solutions
draw_solution(result)

## ----colon-export-------------------------------------------------------------
# Export non-dominated solutions
output_dir <- tempfile("svmfsmeta-colon-")
output_file <- save_results(result, output_dir = output_dir, dataset_name = "colon")
file.exists(output_file)

